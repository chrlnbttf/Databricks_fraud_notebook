# This code aims at reducing the size of the initial fraudDetection.csv file of 350Mb into a 3.5Mb file
import pandas as pd

# Lire le fichier CSV
df = pd.read_csv('data/fraudDetection.csv')

# Échantillonner 1% des données
df_sample = df.sample(frac=0.01, random_state=1)

# Sauvegarder le fichier échantillonné
df_sample.to_csv('fraudDetection_sample.csv', index=False)